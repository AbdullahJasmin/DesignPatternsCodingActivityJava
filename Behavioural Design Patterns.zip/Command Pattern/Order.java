public interface Order {
    void execute();
 }